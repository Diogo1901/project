var searchData=
[
  ['text_0',['text',['../struct_comment.html#ac8c00ec4c0142c2f7d1f0967f3f69c6e',1,'Comment']]],
  ['title_1',['title',['../struct_comment.html#ac0a5bd5e074e21bd44117a91f7ba4b4f',1,'Comment']]]
];

var searchData=
[
  ['getcategoryname_0',['getCategoryName',['../utilities_8c.html#a925b4e9e18e8915882ade45986a2ab8a',1,'getCategoryName(Categoria category):&#160;utilities.c'],['../utilities_8h.html#a925b4e9e18e8915882ade45986a2ab8a',1,'getCategoryName(Categoria category):&#160;utilities.c']]]
];

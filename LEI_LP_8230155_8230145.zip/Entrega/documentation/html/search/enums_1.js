var searchData=
[
  ['searchcriterion_0',['SearchCriterion',['../utilities_8h.html#af8ed050c27d891158def4fa70618be2c',1,'utilities.h']]]
];

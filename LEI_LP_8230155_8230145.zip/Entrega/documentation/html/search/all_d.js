var searchData=
[
  ['savebusinesssectorstofile_0',['saveBusinessSectorsToFile',['../utilities_8c.html#ad43e6837c34f8b73d35e2b49a34b7c2d',1,'saveBusinessSectorsToFile(BusinessSector *businessSectors, int numBusinessSectors):&#160;utilities.c'],['../utilities_8h.html#ad43e6837c34f8b73d35e2b49a34b7c2d',1,'saveBusinessSectorsToFile(BusinessSector *businessSectors, int numBusinessSectors):&#160;utilities.c']]],
  ['savecommentstofile_1',['saveCommentsToFile',['../utilities_8c.html#a335c7c57af7756d74be7d721ce1117bb',1,'saveCommentsToFile(Company companies[], int numCompanies):&#160;utilities.c'],['../utilities_8h.html#a335c7c57af7756d74be7d721ce1117bb',1,'saveCommentsToFile(Company companies[], int numCompanies):&#160;utilities.c']]],
  ['savecompaniestofile_2',['saveCompaniesToFile',['../utilities_8c.html#ae7c54654feca9d1482170f5121e059f8',1,'saveCompaniesToFile(Company companies[], int numCompanies):&#160;utilities.c'],['../utilities_8h.html#ae7c54654feca9d1482170f5121e059f8',1,'saveCompaniesToFile(Company companies[], int numCompanies):&#160;utilities.c']]],
  ['savecompanycount_3',['saveCompanyCount',['../utilities_8c.html#aa5038cc7a02709283c1c3beaefac021a',1,'saveCompanyCount(int numCompanies):&#160;utilities.c'],['../utilities_8h.html#aa5038cc7a02709283c1c3beaefac021a',1,'saveCompanyCount(int numCompanies):&#160;utilities.c']]],
  ['savenotremovedcompaniestofile_4',['saveNotRemovedCompaniesToFile',['../utilities_8c.html#a57acdba50f71b906327c25a1f7efc0a0',1,'saveNotRemovedCompaniesToFile(int numCompanies):&#160;utilities.c'],['../utilities_8h.html#a57acdba50f71b906327c25a1f7efc0a0',1,'saveNotRemovedCompaniesToFile(int numCompanies):&#160;utilities.c']]],
  ['saveratingstofile_5',['saveRatingsToFile',['../utilities_8c.html#aa17b326071b01c61d332a619c1ca3b69',1,'saveRatingsToFile(Company companies[], int numCompanies):&#160;utilities.c'],['../utilities_8h.html#aa17b326071b01c61d332a619c1ca3b69',1,'saveRatingsToFile(Company companies[], int numCompanies):&#160;utilities.c']]],
  ['search_5fcategory_6',['SEARCH_CATEGORY',['../utilities_8h.html#af8ed050c27d891158def4fa70618be2cadcd1b3e9d43d27fec19e19297de0b1df',1,'utilities.h']]],
  ['search_5flocality_7',['SEARCH_LOCALITY',['../utilities_8h.html#af8ed050c27d891158def4fa70618be2ca6ce9143c56a7e2e85c1f303cbd500e6d',1,'utilities.h']]],
  ['search_5fname_8',['SEARCH_NAME',['../utilities_8h.html#af8ed050c27d891158def4fa70618be2ca8047ba957a9650ba048cb02e82329b2e',1,'utilities.h']]],
  ['searchcompanies_9',['searchCompanies',['../user_8c.html#a78ccda5c7fc7c0fe5c6057008cd1da5d',1,'searchCompanies(Company companies[], int numCompanies):&#160;user.c'],['../user_8h.html#a78ccda5c7fc7c0fe5c6057008cd1da5d',1,'searchCompanies(Company companies[], int numCompanies):&#160;user.c']]],
  ['searchcriterion_10',['SearchCriterion',['../utilities_8h.html#af8ed050c27d891158def4fa70618be2c',1,'utilities.h']]],
  ['sectorlist_11',['sectorList',['../utilities_8c.html#a5aaa519b9458e678d06bbdc53e0137f4',1,'utilities.c']]],
  ['sectors_12',['sectors',['../struct_business_sector_list.html#ac5f4ba85820c85e839c0405f1d0e8025',1,'BusinessSectorList']]],
  ['shiftarray_13',['shiftArray',['../utilities_8c.html#a3c63bcb79071dead37ad3a3134ff49bb',1,'shiftArray(Company *arr, size_t size, size_t index):&#160;utilities.c'],['../utilities_8h.html#a3c63bcb79071dead37ad3a3134ff49bb',1,'shiftArray(Company *arr, size_t size, size_t index):&#160;utilities.c']]],
  ['small_14',['SMALL',['../utilities_8h.html#acaa0814a33d4074ea089f95d4bf9aa85aea5e596a553757a677cb4da4c8a1f935',1,'utilities.h']]],
  ['street_15',['street',['../struct_company.html#aed717564d91bac8df8860cf1540ad41a',1,'Company']]]
];

var searchData=
[
  ['initial_5fbuffer_5fsize_0',['INITIAL_BUFFER_SIZE',['../utilities_8h.html#a1d51567e0f6916e91f5bd3719d56cce6',1,'utilities.h']]]
];

var searchData=
[
  ['isactive_0',['isActive',['../struct_business_sector.html#a96eff8420fb9ee1b4c5d5f1bcace116d',1,'BusinessSector']]]
];

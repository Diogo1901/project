var searchData=
[
  ['findindexbynif_0',['findIndexByNIF',['../utilities_8c.html#a88247eab6600d640d743fefdcdd3c9dd',1,'findIndexByNIF(int nif):&#160;utilities.c'],['../utilities_8h.html#a88247eab6600d640d743fefdcdd3c9dd',1,'findIndexByNIF(int nif):&#160;utilities.c']]],
  ['freebusinesssectorlist_1',['freeBusinessSectorList',['../utilities_8c.html#a96c153196b32efc0c9881c6a02a40b85',1,'freeBusinessSectorList(BusinessSectorList *sectorList):&#160;utilities.c'],['../utilities_8h.html#a96c153196b32efc0c9881c6a02a40b85',1,'freeBusinessSectorList(BusinessSectorList *sectorList):&#160;utilities.c']]]
];

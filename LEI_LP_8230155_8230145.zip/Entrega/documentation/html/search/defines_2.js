var searchData=
[
  ['max_5fcomments_0',['MAX_COMMENTS',['../utilities_8h.html#a950d1b78f6687d479f95852cc1387fe3',1,'utilities.h']]],
  ['max_5fcompanies_1',['MAX_COMPANIES',['../utilities_8h.html#a33fc9f727233c1b481ac709bfd55965e',1,'utilities.h']]],
  ['max_5frating_2',['MAX_RATING',['../utilities_8h.html#ace92d66bfbb1eb4c589ba49c3b815921',1,'utilities.h']]],
  ['max_5fratings_3',['MAX_RATINGS',['../utilities_8h.html#a4c5dca3dcf5e20e92d5043cf68ca0797',1,'utilities.h']]],
  ['min_5frating_4',['MIN_RATING',['../utilities_8h.html#a5a74452ec7512441d2e762c162735689',1,'utilities.h']]]
];

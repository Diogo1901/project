var searchData=
[
  ['user_2ec_0',['user.c',['../user_8c.html',1,'']]],
  ['user_2eh_1',['user.h',['../user_8h.html',1,'']]],
  ['username_2',['username',['../struct_comment.html#a3dae4259c0ca612dbb2b1ac5f21def5d',1,'Comment']]],
  ['utilities_2ec_3',['utilities.c',['../utilities_8c.html',1,'']]],
  ['utilities_2eh_4',['utilities.h',['../utilities_8h.html',1,'']]]
];

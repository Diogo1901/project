var searchData=
[
  ['postalcode_0',['postalCode',['../struct_company.html#af414e5f7f587fd593380dcdff94343f7',1,'Company']]]
];

var searchData=
[
  ['big_0',['BIG',['../utilities_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a4e4825dfb3c3a4c83ed71e2a38a3a70d',1,'utilities.h']]]
];

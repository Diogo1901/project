var searchData=
[
  ['categoria_0',['Categoria',['../utilities_8h.html#acaa0814a33d4074ea089f95d4bf9aa85',1,'utilities.h']]]
];

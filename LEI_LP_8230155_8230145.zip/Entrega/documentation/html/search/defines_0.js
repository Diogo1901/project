var searchData=
[
  ['buffer_5fincrement_0',['BUFFER_INCREMENT',['../utilities_8h.html#aee8c6c11b1b61bb7409f769326aeddc4',1,'utilities.h']]]
];

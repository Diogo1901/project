var searchData=
[
  ['sectorlist_0',['sectorList',['../utilities_8c.html#a5aaa519b9458e678d06bbdc53e0137f4',1,'utilities.c']]],
  ['sectors_1',['sectors',['../struct_business_sector_list.html#ac5f4ba85820c85e839c0405f1d0e8025',1,'BusinessSectorList']]],
  ['street_2',['street',['../struct_company.html#aed717564d91bac8df8860cf1540ad41a',1,'Company']]]
];

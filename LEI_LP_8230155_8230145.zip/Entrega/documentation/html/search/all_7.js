var searchData=
[
  ['initial_5fbuffer_5fsize_0',['INITIAL_BUFFER_SIZE',['../utilities_8h.html#a1d51567e0f6916e91f5bd3719d56cce6',1,'utilities.h']]],
  ['isactive_1',['isActive',['../struct_business_sector.html#a96eff8420fb9ee1b4c5d5f1bcace116d',1,'BusinessSector']]],
  ['isbusinesssectorinuse_2',['isBusinessSectorInUse',['../utilities_8c.html#a34f062edb734919e5fa4b243b1f8c784',1,'isBusinessSectorInUse(const Company *companies, int numCompanies, const char *businessSector):&#160;utilities.c'],['../utilities_8h.html#a34f062edb734919e5fa4b243b1f8c784',1,'isBusinessSectorInUse(const Company *companies, int numCompanies, const char *businessSector):&#160;utilities.c']]],
  ['isvalidpostalcode_3',['isValidPostalCode',['../utilities_8c.html#a01072c25e11e9a6736e95ec4f8bf4cdb',1,'isValidPostalCode(const char *postalCode):&#160;utilities.c'],['../utilities_8h.html#a01072c25e11e9a6736e95ec4f8bf4cdb',1,'isValidPostalCode(const char *postalCode):&#160;utilities.c']]]
];

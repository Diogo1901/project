var searchData=
[
  ['editcompany_0',['editCompany',['../adm_8c.html#a4e12d3852a895070f73159cf740a510e',1,'editCompany():&#160;adm.c'],['../adm_8h.html#a4e12d3852a895070f73159cf740a510e',1,'editCompany():&#160;adm.c']]]
];

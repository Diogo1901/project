var searchData=
[
  ['ratings_0',['ratings',['../struct_company.html#a6a9a87bf86a52da7889d9fc7f859895f',1,'Company']]]
];

var searchData=
[
  ['active_0',['active',['../struct_company.html#aa5805c5e936174e5092bf7a5b78e7e64',1,'Company']]],
  ['activestatus_1',['activeStatus',['../struct_business_sector_list.html#ad78adf4d9c67774b70e6363e525d9712',1,'BusinessSectorList']]],
  ['activity_2',['activity',['../struct_company.html#ac0deb573f3d649dde8fcca3506f96450',1,'Company']]],
  ['adm_2ec_3',['adm.c',['../adm_8c.html',1,'']]],
  ['adm_2eh_4',['adm.h',['../adm_8h.html',1,'']]],
  ['averagerating_5',['averageRating',['../struct_company.html#a99c27ddd21ecaaf77de2153ea5d352c6',1,'Company']]]
];

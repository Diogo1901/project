var searchData=
[
  ['comment_0',['Comment',['../struct_comment.html',1,'']]],
  ['company_1',['Company',['../struct_company.html',1,'']]]
];

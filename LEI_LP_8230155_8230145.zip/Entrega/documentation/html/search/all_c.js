var searchData=
[
  ['ratecompany_0',['rateCompany',['../user_8c.html#a5b07077cf69b7ea6c06da794d126bd84',1,'rateCompany(Company companies[], int numCompanies):&#160;user.c'],['../user_8h.html#a5b07077cf69b7ea6c06da794d126bd84',1,'rateCompany(Company companies[], int numCompanies):&#160;user.c']]],
  ['ratings_1',['ratings',['../struct_company.html#a6a9a87bf86a52da7889d9fc7f859895f',1,'Company']]],
  ['removebusinesssector_2',['removeBusinessSector',['../adm_8c.html#ac3bc153913ea89b56b60594690490c08',1,'removeBusinessSector():&#160;adm.c'],['../adm_8h.html#ac3bc153913ea89b56b60594690490c08',1,'removeBusinessSector():&#160;adm.c']]],
  ['removecompany_3',['removeCompany',['../adm_8c.html#a8f18263939cb30052bfb689fae105375',1,'removeCompany():&#160;adm.c'],['../adm_8h.html#a8f18263939cb30052bfb689fae105375',1,'removeCompany():&#160;adm.c']]],
  ['report_2ec_4',['report.c',['../report_8c.html',1,'']]],
  ['report_2eh_5',['report.h',['../report_8h.html',1,'']]]
];

var searchData=
[
  ['big_0',['BIG',['../utilities_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a4e4825dfb3c3a4c83ed71e2a38a3a70d',1,'utilities.h']]],
  ['buffer_5fincrement_1',['BUFFER_INCREMENT',['../utilities_8h.html#aee8c6c11b1b61bb7409f769326aeddc4',1,'utilities.h']]],
  ['businesssector_2',['BusinessSector',['../struct_business_sector.html',1,'']]],
  ['businesssector_3',['businessSector',['../struct_company.html#a3541e04e44a3e56c0c8dc2c04ccc5574',1,'Company']]],
  ['businesssectorlist_4',['BusinessSectorList',['../struct_business_sector_list.html',1,'']]]
];

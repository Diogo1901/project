var searchData=
[
  ['name_0',['name',['../struct_company.html#aeaf846aa21a7d016a52f0b5b0c2f5544',1,'Company::name'],['../struct_business_sector.html#aeaf846aa21a7d016a52f0b5b0c2f5544',1,'BusinessSector::name']]],
  ['nif_1',['nif',['../struct_company.html#ad68c6985dce5a3d709f854778dedee19',1,'Company']]],
  ['numcomments_2',['numComments',['../struct_company.html#a36243e59177e5f7fea16ee57a3341c42',1,'Company::numComments'],['../utilities_8c.html#a36243e59177e5f7fea16ee57a3341c42',1,'numComments:&#160;utilities.c'],['../utilities_8h.html#a36243e59177e5f7fea16ee57a3341c42',1,'numComments:&#160;utilities.c']]],
  ['numcompanies_3',['numCompanies',['../utilities_8c.html#a14968c4ceca33796adccfdf7d99c71fa',1,'numCompanies:&#160;utilities.c'],['../utilities_8h.html#a14968c4ceca33796adccfdf7d99c71fa',1,'numCompanies:&#160;utilities.c']]],
  ['numratings_4',['numRatings',['../struct_company.html#a99daed95fe8f93a761a4588154a4822e',1,'Company']]],
  ['numsectors_5',['numSectors',['../struct_business_sector_list.html#a82d87412408f94a65586dae91eae2bee',1,'BusinessSectorList']]]
];

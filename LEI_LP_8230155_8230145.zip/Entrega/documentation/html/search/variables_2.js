var searchData=
[
  ['category_0',['category',['../struct_company.html#a56529688a462f8f88e83d5750e9edd8b',1,'Company']]],
  ['comments_1',['comments',['../struct_company.html#a151a45c5c6629b42c4f2cfc693060936',1,'Company']]],
  ['companies_2',['companies',['../utilities_8c.html#a19add1edf20b7147e62d2c7a282086e6',1,'companies:&#160;utilities.c'],['../utilities_8h.html#a19add1edf20b7147e62d2c7a282086e6',1,'companies:&#160;utilities.c']]]
];

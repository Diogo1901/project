var searchData=
[
  ['businesssector_0',['businessSector',['../struct_company.html#a3541e04e44a3e56c0c8dc2c04ccc5574',1,'Company']]]
];

var searchData=
[
  ['locality_0',['locality',['../struct_company.html#af61782fb4ab2752cbf3ebd5906a66c9b',1,'Company']]]
];

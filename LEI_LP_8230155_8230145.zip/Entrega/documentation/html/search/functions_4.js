var searchData=
[
  ['isbusinesssectorinuse_0',['isBusinessSectorInUse',['../utilities_8c.html#a34f062edb734919e5fa4b243b1f8c784',1,'isBusinessSectorInUse(const Company *companies, int numCompanies, const char *businessSector):&#160;utilities.c'],['../utilities_8h.html#a34f062edb734919e5fa4b243b1f8c784',1,'isBusinessSectorInUse(const Company *companies, int numCompanies, const char *businessSector):&#160;utilities.c']]],
  ['isvalidpostalcode_1',['isValidPostalCode',['../utilities_8c.html#a01072c25e11e9a6736e95ec4f8bf4cdb',1,'isValidPostalCode(const char *postalCode):&#160;utilities.c'],['../utilities_8h.html#a01072c25e11e9a6736e95ec4f8bf4cdb',1,'isValidPostalCode(const char *postalCode):&#160;utilities.c']]]
];

var searchData=
[
  ['businesssector_0',['BusinessSector',['../struct_business_sector.html',1,'']]],
  ['businesssectorlist_1',['BusinessSectorList',['../struct_business_sector_list.html',1,'']]]
];

var searchData=
[
  ['main_0',['main',['../main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['max_5fcomments_2',['MAX_COMMENTS',['../utilities_8h.html#a950d1b78f6687d479f95852cc1387fe3',1,'utilities.h']]],
  ['max_5fcompanies_3',['MAX_COMPANIES',['../utilities_8h.html#a33fc9f727233c1b481ac709bfd55965e',1,'utilities.h']]],
  ['max_5frating_4',['MAX_RATING',['../utilities_8h.html#ace92d66bfbb1eb4c589ba49c3b815921',1,'utilities.h']]],
  ['max_5fratings_5',['MAX_RATINGS',['../utilities_8h.html#a4c5dca3dcf5e20e92d5043cf68ca0797',1,'utilities.h']]],
  ['medium_6',['MEDIUM',['../utilities_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a5340ec7ecef6cc3886684a3bd3450d64',1,'utilities.h']]],
  ['micro_7',['MICRO',['../utilities_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a44fead913cf8397fe4cf15b7c8962a8f',1,'utilities.h']]],
  ['min_5frating_8',['MIN_RATING',['../utilities_8h.html#a5a74452ec7512441d2e762c162735689',1,'utilities.h']]]
];

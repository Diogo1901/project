var searchData=
[
  ['username_0',['username',['../struct_comment.html#a3dae4259c0ca612dbb2b1ac5f21def5d',1,'Comment']]]
];

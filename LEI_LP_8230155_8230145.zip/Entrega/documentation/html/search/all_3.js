var searchData=
[
  ['calculateaveragerating_0',['calculateAverageRating',['../utilities_8c.html#ace5a16e4d51d5fb780a4982c51c04f73',1,'calculateAverageRating(float ratings[], int numRatings):&#160;utilities.c'],['../utilities_8h.html#ace5a16e4d51d5fb780a4982c51c04f73',1,'calculateAverageRating(float ratings[], int numRatings):&#160;utilities.c']]],
  ['categoria_1',['Categoria',['../utilities_8h.html#acaa0814a33d4074ea089f95d4bf9aa85',1,'utilities.h']]],
  ['category_2',['category',['../struct_company.html#a56529688a462f8f88e83d5750e9edd8b',1,'Company']]],
  ['changebusinessstatus_3',['changeBusinessStatus',['../adm_8c.html#a44c275ee34db8bc0b617b958d30cf99d',1,'changeBusinessStatus():&#160;adm.c'],['../adm_8h.html#a44c275ee34db8bc0b617b958d30cf99d',1,'changeBusinessStatus():&#160;adm.c']]],
  ['choosebusinesssector_4',['chooseBusinessSector',['../adm_8c.html#a9002557ad8feb716da351e80efab1277',1,'chooseBusinessSector(BusinessSectorList *sectorList):&#160;adm.c'],['../adm_8h.html#a9002557ad8feb716da351e80efab1277',1,'chooseBusinessSector(BusinessSectorList *sectorList):&#160;adm.c']]],
  ['comment_5',['Comment',['../struct_comment.html',1,'']]],
  ['commentcompany_6',['commentCompany',['../user_8c.html#a3bf8ed05bd8ebebfbdc1b3de839b4974',1,'commentCompany(Comment comments[], int *numComments):&#160;user.c'],['../user_8h.html#a3bf8ed05bd8ebebfbdc1b3de839b4974',1,'commentCompany(Comment comments[], int *numComments):&#160;user.c']]],
  ['comments_7',['comments',['../struct_company.html#a151a45c5c6629b42c4f2cfc693060936',1,'Company']]],
  ['companies_8',['companies',['../utilities_8c.html#a19add1edf20b7147e62d2c7a282086e6',1,'companies:&#160;utilities.c'],['../utilities_8h.html#a19add1edf20b7147e62d2c7a282086e6',1,'companies:&#160;utilities.c']]],
  ['company_9',['Company',['../struct_company.html',1,'']]],
  ['companyhascomments_10',['companyHasComments',['../utilities_8c.html#acb679e618016182bcd15122b5336c408',1,'companyHasComments(int index):&#160;utilities.c'],['../utilities_8h.html#acb679e618016182bcd15122b5336c408',1,'companyHasComments(int index):&#160;utilities.c']]],
  ['createbusinesssector_11',['createBusinessSector',['../adm_8c.html#a2194946965c2b1063c4da794c86928c0',1,'createBusinessSector():&#160;adm.c'],['../adm_8h.html#a2194946965c2b1063c4da794c86928c0',1,'createBusinessSector():&#160;adm.c']]],
  ['createcompany_12',['createCompany',['../adm_8c.html#a47eea4d1a708afc60ce08dcb1296436c',1,'createCompany():&#160;adm.c'],['../adm_8h.html#a47eea4d1a708afc60ce08dcb1296436c',1,'createCompany():&#160;adm.c']]]
];
